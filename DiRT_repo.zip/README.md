# DiRT Candidate Index Gene Finder

This repository contains a Python script that identifies candidate index genes
for each target gene based on normalized dispersion (std/mean) of ratios
in control samples.

## Requirements
- Python 3.x
- pandas
- numpy

Install:
```bash
pip install pandas numpy
```

## Input file
Place a CSV named `Test.csv` in the same folder. The file must include:
- A first column named `Geneid`.
- CPM values for samples `C1..C9` (controls) and `T1..T9` (treated).

## Usage
Run:
```bash
python dirt_tencand.py
```

Output:
- `DiRT_test.csv` containing the concatenated top-10 candidate index genes
  for the first 10 target genes.

## Full run (optional)
Running all ~10,000 genes is slow. You can split the workload (see code comments)
to produce `DiRT_test1.csv` and `DiRT_test2.csv`, then merge.
